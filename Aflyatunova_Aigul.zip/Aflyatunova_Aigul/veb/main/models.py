from django.db import models

class Events(models.Model):
    title = models.CharField("Название", max_length=250)
    date = models.DateField("Дата")
    description = models.TextField("Описание")

    def __str__(self):
        return self.title